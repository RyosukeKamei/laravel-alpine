/*
 * 統合ＤＢシステム
 * 共通機能 積立ツール SSOログイン受付
 *
 * --修正履歴----
 * 修正日付   NO    修正者   修正履歴
 * 2017/03/06 0001  賀川     Ph.19.0 積立ツールSSOログイン対応
 *
 */
package jp.co.stonesystem.unvrs.action.portal.sso;

import java.io.File;
import java.sql.Timestamp;
import java.util.Date;
import java.util.List;

import javax.annotation.Resource;

import jp.co.stonesystem.unvrs.action.BaseAction;
import jp.co.stonesystem.unvrs.common.ApplicationException;
import jp.co.stonesystem.unvrs.common.Constants;
import jp.co.stonesystem.unvrs.common.LogLevel;
import jp.co.stonesystem.unvrs.dto.FundingToolSSOResponseDto;
import jp.co.stonesystem.unvrs.dto.FundingToolTradeInfoDto;
import jp.co.stonesystem.unvrs.entity.TmService;
import jp.co.stonesystem.unvrs.entity.TmSystemSetInfo;
import jp.co.stonesystem.unvrs.entity.TtClientBase;
import jp.co.stonesystem.unvrs.entity.TtClientPortal;
import jp.co.stonesystem.unvrs.form.portal.sso.C0008Form;
import jp.co.stonesystem.unvrs.service.ThClientConfirmService;
import jp.co.stonesystem.unvrs.service.ThClientLoginService;
import jp.co.stonesystem.unvrs.service.TtApplBaseService;
import jp.co.stonesystem.unvrs.service.TtCampaignService;
import jp.co.stonesystem.unvrs.service.TtClientBaseService;
import jp.co.stonesystem.unvrs.service.TtClientPortalService;
import jp.co.stonesystem.unvrs.service.TtClientTradeService;
import jp.co.stonesystem.unvrs.service.TxMarketInfoService;
import jp.co.stonesystem.unvrs.util.CipherAlgorithm;
import jp.co.stonesystem.unvrs.util.CipherUtil;
import jp.co.stonesystem.unvrs.util.DateUtil;
import jp.co.stonesystem.unvrs.util.MessageDigestAlgorithm;
import jp.co.stonesystem.unvrs.util.SSOTransUtil;
import jp.co.stonesystem.unvrs.util.StringUtil;
import jp.co.stonesystem.unvrs.util.SysUtil;

import net.arnx.jsonic.JSON;

import org.apache.commons.logging.Log;
import org.apache.commons.logging.LogFactory;
import org.seasar.framework.beans.converter.DateConverter;
import org.seasar.framework.beans.util.Beans;
import org.seasar.struts.annotation.ActionForm;
import org.seasar.struts.annotation.Execute;

/** 積立ツール SSOログイン受付 */
public class FtLinkAction extends BaseAction {
    /** ログ */
    private static Log log = LogFactory.getLog(FtLinkAction.class);

    /** SSOログイン受付フォーム (パラメータ取得) */
    @Resource
    @ActionForm
    protected C0008Form c0008Form;

    /** 顧客基本情報 */
    @Resource
    protected TtClientBaseService ttClientBaseService;
    /** 顧客ポータル情報 */
    @Resource
    protected TtClientPortalService ttClientPortalService;
    /** 取引口座情報 */
    @Resource
    protected TtClientTradeService ttClientTradeService;
    /** 顧客情報確認履歴 */
    @Resource
    protected ThClientConfirmService thClientConfirmService;
    /** 申込基本情報 */
    @Resource
    protected TtApplBaseService ttApplBaseService;
    /** キャンペーン情報 */
    @Resource
    protected TtCampaignService ttCampaignService;
    /** マーケット情報（ニュース） */
    @Resource
    protected TxMarketInfoService txMarketInfoService;
    /** 顧客ログイン履歴 */
    @Resource
    protected ThClientLoginService thClientLoginService;


    /**
     * SSOログイン受付制御
     *
     * @return null
     */
    @Execute(validator = false)
    public String index() {

        return null;
    }

    /**
     * SSOログイン受付制御
     *
     * @return 追加口座開設遷移指定で、対象の口座が申込済み、開設済みの場合は、追加申込拒否画面表示<br />
     *         それ以外の場合、取引用ID・初期パスワード確認
     * @throws Exception エラー
     */
    @Execute(validator = false)
    public String login() throws Exception {
        DateUtil dateUtil = DateUtil.getInstance();
        Date date = dateUtil.getSystemDate();
        Timestamp timestamp = dateUtil.getSystemTimestamp();

        String data = c0008Form.data;
        String hash = c0008Form.messageDigest;

        // 暗号化キー取得
        String keyFilePath = tmSystemSetInfoService.getTmSystemSetInfo(Constants.PATH_CIPHER_UTIL_KEY_FILE_FUNDING_TOOL,
                true, false, false).textValue1;

        // 有効期限取得
        String msecValueStr = tmSystemSetInfoService.getTmSystemSetInfo(Constants.SSO_LOGIN_SESSION_TIMEOUT,
                true, false, false).textValue1;
        int msecValid = Integer.parseInt(msecValueStr);
        Date validDate = new Date(date.getTime() - msecValid);

        // SSO認証情報チェック
        if (StringUtil.isBlank(data) || StringUtil.isBlank(hash)) {
            throw new ApplicationException("パラメータが存在しない",
                    Constants.EXP_RES_KEY_INVALID_REQUEST, false,
                    LogLevel.WARNING);
        }

        // 認証情報の複合化
        File keyFile = new File(keyFilePath);
        String decryptedString = (String) CipherUtil.decrypt(
                keyFile.getAbsolutePath(),
                data,
                hash,
                CipherAlgorithm.AES_CBC_PKC5Padding_KEY128_BLOCK128,
                MessageDigestAlgorithm.SHA256);

        // 値が存在しない場合、エラー
        if (decryptedString == null) {
            // エラー画面 「ログインされていません」
            throw new ApplicationException("SSO認証チェック",
                    Constants.EXP_RES_KEY_INVALID_REQUEST, true);
        }

        FundingToolSSOResponseDto fundingToolSSOResponseDto =
                JSON.decode(decryptedString, FundingToolSSOResponseDto.class);

        // 認証情報の確認
        if(
                fundingToolSSOResponseDto.portalId == null ||
                fundingToolSSOResponseDto.tradeList.isEmpty() ||
                fundingToolSSOResponseDto.systemDate == null ||
                fundingToolSSOResponseDto.redirectUrlKey == null
                ) {
            log.warn("SSO portalId:" + fundingToolSSOResponseDto.portalId);
            for (FundingToolTradeInfoDto fundingToolTrade: fundingToolSSOResponseDto.tradeList) {
                log.warn("SSO tradeList.serviceCd:" + fundingToolTrade.serviceCd);
                log.warn("SSO tradeList.tradeLoginId:" + fundingToolTrade.tradeLoginId);
            }
            log.warn("SSO tradeList:" + fundingToolSSOResponseDto.tradeList);
            log.warn("SSO systemDate:" + fundingToolSSOResponseDto.systemDate);
            log.warn("SSO redirectUrlKey:" + fundingToolSSOResponseDto.redirectUrlKey);
            throw new ApplicationException("SSO認証チェック",
                    Constants.EXP_RES_KEY_INVALID_REQUEST, true);
        }

        // SSOログイン有効期限チェック
        Date requestDate = dateUtil.toFormatDate(fundingToolSSOResponseDto.systemDate, DateUtil.FMT_OUT_TIMESTAMP);
        if (requestDate == null || requestDate.before(validDate)) {
            log.warn("requestDate:" + requestDate + " validDate:" + validDate);
            // エラー画面 「ページの有効期限切れです」
            throw new ApplicationException("SSO認証チェック",
                    Constants.EXP_RES_KEY_INVALID_TERM, true);
        }

        // 遷移先URL取得
        TmSystemSetInfo redirectUrlSystemSetInfo = tmSystemSetInfoService.findCurrent(
                fundingToolSSOResponseDto.redirectUrlKey, dateUtil.getDBSystemDate());
        // 遷移先URLが取得できない場合、システムエラー
        if (redirectUrlSystemSetInfo == null || StringUtil.isBlank(redirectUrlSystemSetInfo.textValue1)) {
            log.warn("redirectUrlKey:" + fundingToolSSOResponseDto.redirectUrlKey);
            throw new ApplicationException("SSO認証チェック", Constants.EXP_RES_KEY_INVALID_REQUEST);
        }
        String forward = redirectUrlSystemSetInfo.textValue1;
        String forwardMenuNo = redirectUrlSystemSetInfo.textValue2;
        String changeServiceCd = redirectUrlSystemSetInfo.textValue3;

        // 認証チェック
        TtClientPortal ttClientPortal = ttClientPortalService.findByPortalId(fundingToolSSOResponseDto.portalId);
        if (ttClientPortal == null) {
            log.warn("portalId:" + fundingToolSSOResponseDto.portalId);
            // エラー画面 「リクエストが無効です」
            throw new ApplicationException("SSO認証チェック", Constants.EXP_RES_KEY_INVALID_TOKEN, true);
        }

        for (FundingToolTradeInfoDto trade: fundingToolSSOResponseDto.tradeList) {
            if (!ttClientTradeService.checkAccountOpenOnlyOne(ttClientPortal.clientCd, trade.serviceCd)) {
                throw new ApplicationException("SSO認証チェック");
            }
        }

        // DB登録処理
        // 内部ログイン処理
        // 認証情報更新
        // ポータルIDがロックされている場合も取引システム認証済みのため、ロックを解除
        ttClientPortal.authFailCnt = 0;
        Timestamp lastLoginTs = ttClientPortal.lastAuthTs;
        ttClientPortal.lastAuthTs = timestamp;
        ttClientPortalService.alterAuthInfo(ttClientPortal);

        // 顧客ログイン履歴登録
        String userAgent = request.getHeader("User-Agent");
        String deviceKbn = SysUtil.getInstance().getDeviceKbn(userAgent);
        String userAgentFix = null;
        if (userAgent != null) {
            userAgentFix = userAgent.substring(0, Math.min(255, userAgent.length()));
        }
        String systemKbn = Constants.SYSTEM_KBN_SSO_LOGIN_FUNDING_TOOL;
        thClientLoginService.insertThClientLogin(
                fundingToolSSOResponseDto.portalId,
                ttClientPortal.clientCd,
                deviceKbn, userAgentFix,
                Constants.LOGIN_ROOT_KBN_SSO_LOGIN,
                systemKbn,
                timestamp);

        // セッションへの保存処理
        Beans.copy(ttClientPortal, userDto).execute();
        if (lastLoginTs != null) {
            userDto.lastLoginDate = new DateConverter(DateUtil.FMT_OUT_YMDH).getAsString(lastLoginTs);
        } else {
            userDto.lastLoginDate = DateUtil.FMT_LAST_LOGIN.replace("yyyy", "-").replace("M", "-").replace("d", "-")
                    .replace("HH", "-").replace("mm", "-");
        }

        // 顧客基本情報情報を取得できない場合、エラー
        TtClientBase ttClientBase = ttClientBaseService.findByClientCd(ttClientPortal.clientCd);
        if (ttClientBase == null) {
            log.warn("clientCd:" + ttClientPortal.clientCd);
            // エラー画面 「リクエストが無効です」
            throw new ApplicationException("SSO認証チェック", Constants.EXP_RES_KEY_INVALID_TOKEN, true);
        }

        setSessionClientBase(ttClientBase);

        // 口座開設状況設定
        loadServiceStatus(ttClientTradeService, ttApplBaseService);

        // 追加口座開設遷移指定で、対象の口座が申込済み、開設済みの場合は、追加申込拒否画面表示
        String refusalUrl = SSOTransUtil.refusalAddOpen(fundingToolSSOResponseDto.redirectUrlKey,
                userDto.serviceStatusMap);
        if (refusalUrl != null) {
            return refusalUrl + "?redirect=true";
        }

        // メニュー制御情報設定
        String selectedMenu = null;
        userDto.selectedServiceCd = systemKbn;
        if (changeServiceCd != null && changeServiceCd.trim().length() > 0) {
            if (changeServiceCd.equals(Constants.SERVICE_CD_EVERY_SERVICE)) {
                userDto.selectedServiceCd = Constants.SERVICE_CD_MYPAGE;
            } else {
                userDto.selectedServiceCd = changeServiceCd;
            }
            userDto.ssoTradeLoginId = null;
            userDto.ssoServiceCd = null;
            userDto.ssoTradeServiceCd = null;
            userDto.ssoClientCd = null;
            userDto.isSsoLogin = false;
        } else {
            userDto.selectedLoginId = null;
        }

        List<TmService> services = tmServiceService.findOrderByServiceCd();
        userDto.serviceImagePathMap = createServiceImagePathMap(services);
        userDto.serviceImagePath = userDto.serviceImagePathMap.get(userDto.selectedServiceCd);
        userDto.serviceLogo1PathMap = createServiceLogo1PathMap(services);
        userDto.serviceLogo2PathMap = createServiceLogo2PathMap(services);

        selectedMenu = userDto.selectedServiceCd;
        if (forwardMenuNo != null && forwardMenuNo.trim().length() > 0) {
            selectedMenu = selectedMenu + "." + forwardMenuNo;
        }
        selectMenu(selectedMenu);
        userDto.redirectUrlKey = fundingToolSSOResponseDto.redirectUrlKey;

        c0008Form.selectedServiceCd = userDto.selectedServiceCd;
        c0008Form.selectedMenu = userDto.selectedMenu;
        c0008Form.serviceImagePath = userDto.serviceImagePath;

        // ニュース情報設定
        setSessionNewsInfo(txMarketInfoService);
        // キャンペーンバナー情報設定
        setSessionBannerInfo(ttCampaignService);
        // サイドバナーURL情報取得
        setSessionSideBannerInfo();
        // レバレッジ変更URL情報取得
        setSessionLeverageChangeInfo();

        forward = "/portal/confirm/tradeIdGen/accept?redirect=true";

        // 遷移先へ
        return forward;
    }

    /**
     * セッション維持不要
     * @return true
     */
    @Override
    public boolean checkNoSession() {
        return true;
    }
}
