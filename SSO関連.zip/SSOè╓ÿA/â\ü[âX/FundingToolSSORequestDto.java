/*
 * 統合ＤＢシステム
 * 積立ツールSSOリクエストパラメータ
 *
 * --修正履歴----
 * 修正日付   NO    修正者   修正履歴
 * 2017/03/06 0001  賀川     新規作成
 *
 */
package jp.co.stonesystem.unvrs.dto;

import java.util.List;
import java.util.Map;

import net.arnx.jsonic.JSONHint;

/** 積立ツールSSOリクエスト DTO */
public class FundingToolSSORequestDto {
    /** ポータルＩＤ */
    @JSONHint(ordinal=1)
    public String portalId;

    /** 顧客区分 */
    @JSONHint(ordinal=2)
    public String clientKbn;

    /** 取引口座情報 */
    @JSONHint(name = "trade", ordinal=3)
    public List<FundingToolTradeInfoDto> tradeList;

    /** JACCSステータス */
    @JSONHint(ordinal=4)
    public String jaccsStatus;

    /** 不備情報 */
    @JSONHint(ordinal=5)
    public Map<String, String> defectInfo;

    /** システム日時 */
    @JSONHint(ordinal=6)
    public String systemDate;
}
