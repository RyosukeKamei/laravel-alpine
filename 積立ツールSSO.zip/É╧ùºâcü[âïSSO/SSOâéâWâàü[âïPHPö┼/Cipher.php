<?php
/**
 * 暗号化／復号化クラス
 */
class Cipher
{
    /**
     * 暗号化／復号化メソッドのデフォルト値
     */
    const METHOD = 'AES-128-CBC';

    /**
     * ハッシュ値の生成に使用するアルゴリズムのデフォルト値
     */
    const MESSAGE_DIGEST_ALGORITHM = 'sha256';

    /**
     * 暗号化を行う
     *
     * 暗号化するデータに配列や連想配列、オブジェクトが渡された場合は JSON 形式に変換して暗号化する
     *
     * @param string $key 暗号化に使用するキー文字列
     * @param string|array|object $data 暗号化するデータ
     * @param string $method 暗号化メソッド（省略可）
     * @return string|false 成功した場合は暗号化した文字列、失敗した場合は false を返却する
     */
    public static function encrypt($key, $data, $method = self::METHOD)
    {
        $value = is_array($data) || $data instanceof stdClass
            ? json_encode($data)
            : $data;

        $ivLength = openssl_cipher_iv_length($method);

        $iv = openssl_random_pseudo_bytes($ivLength);

        $encrypt = openssl_encrypt(
            $value,
            $method,
            substr($key, strlen($key) - $ivLength),
            0,
            $iv
        );

        return bin2hex($iv) . bin2hex(base64_decode($encrypt));
    }

    /**
     * 復号化を行う
     *
     * @param string $key 復号化に使用するキー文字列
     * @param string $data 復号化する暗号化文字列
     * @param string $method 復号化メソッド（省略可）
     * @param string $messageDigestAlgorithm ハッシュ値の検証に使用するアルゴリズム（省略可）
     * @return string|false 成功した場合は復号化した文字列、失敗した場合は false を返却する
     */
    public static function decrypt($key, $data, $hash, $method = self::METHOD, $messageDigestAlgorithm = self::MESSAGE_DIGEST_ALGORITHM)
    {
        if (self::createHash($data, $messageDigestAlgorithm) != $hash)
        {
            return false;
        }

        $ivLength = openssl_cipher_iv_length($method);

        $iv = hex2bin(substr($data, 0, $ivLength * 2));

        $decrypt = openssl_decrypt(
            hex2bin(substr($data, strlen($iv) * 2)),
            $method,
            substr($key, strlen($key) - $ivLength),
            OPENSSL_RAW_DATA,
            $iv
        );

        return $decrypt;
    }

    /**
     * ハッシュ値を生成する
     *
     * @param string $encryptedData ハッシュする値
     * @param string $messageDigestAlgorithm ハッシュ値の生成に使用するアルゴリズム（省略可）
     * @return string ハッシュ値
     */
    public static function createHash($data, $messageDigestAlgorithm = self::MESSAGE_DIGEST_ALGORITHM)
    {
        return hash($messageDigestAlgorithm, $data, false);
    }
}
