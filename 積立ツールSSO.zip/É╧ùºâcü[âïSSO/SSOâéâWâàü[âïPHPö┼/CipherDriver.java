import jp.co.stonesystem.unvrs.util.CipherAlgorithm;
import jp.co.stonesystem.unvrs.util.CipherUtil;
import jp.co.stonesystem.unvrs.util.MessageDigestAlgorithm;

public class CipherDriver {

    public static void main(String[] args) throws Exception {

        try {
            if (args[0].equals("encrypt")) {
                String encrypted = CipherUtil.encrypt(
                    "./ft2048.key",
                    args[1],
                    CipherAlgorithm.AES_CBC_PKC5Padding_KEY128_BLOCK128
                );
                System.out.println(encrypted);
            } else if (args[0].equals("decrypt")) {
                Object decrypted = CipherUtil.decrypt(
                    "./ft2048.key",
                    args[1],
                    args[2],
                    CipherAlgorithm.AES_CBC_PKC5Padding_KEY128_BLOCK128,
                    MessageDigestAlgorithm.SHA256
                );
                System.out.println(decrypted);
            } else if (args[0].equals("createHash")) {
                String hash = CipherUtil.createHash(args[1], MessageDigestAlgorithm.SHA256);
                System.out.println(hash);
            }
        } catch (ArrayIndexOutOfBoundsException e) {

        }

    }

}
