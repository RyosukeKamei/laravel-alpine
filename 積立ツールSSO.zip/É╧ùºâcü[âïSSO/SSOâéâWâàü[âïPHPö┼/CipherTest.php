<?php
    require_once 'Cipher.php';

    $key = file_get_contents('./ft2048.key');

    $cases = array(
        array(
            'title' => 'くりっく365が申込中、トライオートETFだけを開設している顧客でJACCS未開設の顧客の場合',
            'data' => '{"portalId":"12345678","clientKbn":"1","trade":[{"serviceCd":"01","loginId":null,"status":"1"},{"serviceCd":"17","loginId":"12345678","status":"2"}],"jaccsStatus":"0","defectInfo":{"code":"0000"},"systemDate":"2017-03-15 17:51:48.066"}'
        ),
        array(
            'title' => 'くりっく365が申込中、トライオートETFだけを開設している顧客でJACCS開設済の顧客の場合',
            'data' => '{"portalId":"12345678","clientKbn":"1","trade":[{"serviceCd":"01","loginId":null,"status":"1"},{"serviceCd":"17","loginId":"12345678","status":"2"}],"jaccsStatus":"1","defectInfo":{"code":"0000"},"systemDate":"2017-03-15 17:58:50.574"}'
        ),
        array(
            'title' => 'くりっく365が申込中、トライオートETFだけを開設している顧客でJACCS未開設の顧客の場合',
            'data' => '{"portalId":"12345678","clientKbn":"1","trade":[{"serviceCd":"01","loginId":null,"status":"1"},{"serviceCd":"17","loginId":"12345678","status":"2"}],"jaccsStatus":"0","defectInfo":{"code":"0100","message":"顧客情報に不備がありました"},"systemDate":"2017-03-15 17:57:52.421"}'
        )
    );

    foreach ($cases as $case)
    {
        doTest($key, $case['title'], $case['data']);
    }

    function doTest($key, $title, $data)
    {
        print_r("\n");

        print_r("■{$title}\n\n");

        print_r("元文字列：{$data}\n\n");

        print_r("-------------------------\n");

        $encrypted = encryptByJava($data);
        $hash = createHashByJava($encrypted);
        print_r("・Javaで暗号化\n");
        print_r("→暗号化文字列:{$encrypted}\n");
        print_r("→ハッシュ:{$hash}\n\n");

        print_r("・PHPで復号化\n");
        $decrypted = Cipher::decrypt($key, $encrypted, $hash);
        print_r("→復号化したデータ:{$decrypted}\n");

        print_r("-------------------------\n");

        $encrypted = Cipher::encrypt($key, $data);
        $hash = Cipher::createHash($encrypted);
        print_r("・PHPで暗号化\n");
        print_r("→暗号化文字列:{$encrypted}\n");
        print_r("→ハッシュ:{$hash}\n\n");

        print_r("・Javaで復号化\n");
        $decrypted = decryptByJava($encrypted, $hash);
        print_r("→復号化したデータ:{$decrypted}\n");

        print_r("-------------------------\n");
    }

    function encryptByJava($data)
    {
        $output = exec('java -Dfile.encoding=UTF-8 -cp .\;cipher.jar CipherDriver encrypt "' . str_replace('"', '\"', $data) . '"');
        return $output;
    }

    function decryptByJava($data, $hash)
    {
        $output = exec("java -Dfile.encoding=UTF-8 -cp .\;cipher.jar CipherDriver decrypt {$data} {$hash}");
        return $output;
    }

    function createHashByJava($data)
    {
        $output = exec("java -Dfile.encoding=UTF-8 -cp .\;cipher.jar CipherDriver createHash {$data}");
        return $output;
    }
