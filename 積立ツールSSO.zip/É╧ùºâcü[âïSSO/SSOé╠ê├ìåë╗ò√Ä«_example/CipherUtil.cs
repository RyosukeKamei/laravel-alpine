﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Windows.Forms;
using System.Security.Cryptography;
using System.IO;

namespace itd_cipher
{
    public static class CipherUtil
    {
        private const int CRYPTO_BLOCK_SIZE = 128;
        private const int CRYPTO_KEY_SIZE = 128;
        private const CipherMode CRYPTO_CIPHER_MODE = CipherMode.CBC;
        private const PaddingMode CRYPTO_PADDING_MODE = PaddingMode.ISO10126;

        /// <summary>
        /// Encrypts a string.
        /// </summary>
        /// <param name="keyFile">Key file to encrypt with</param>
        /// <param name="data">Text to be encrypted</param>
        /// <returns>An encrypted string</returns>
        public static String encrypt(String keyFile, String data)
        {
            string result = null;

            byte[] dataBytes = Encoding.UTF8.GetBytes(data);

            DESCryptoServiceProvider des = new DESCryptoServiceProvider();

            AesCryptoServiceProvider aes = new AesCryptoServiceProvider();
            aes.BlockSize = CRYPTO_BLOCK_SIZE;
            aes.KeySize = CRYPTO_KEY_SIZE;
            aes.Mode = CRYPTO_CIPHER_MODE;
            aes.Padding = CRYPTO_PADDING_MODE;

            byte[] key = Encoding.UTF8.GetBytes(getKey(keyFile));
            byte[] iv = aes.IV;

            using (MemoryStream memoryStream = new MemoryStream())
            {
                using (CryptoStream cryptoStream =
                    new CryptoStream(memoryStream, aes.CreateEncryptor(key, iv), CryptoStreamMode.Write))
                {
                    cryptoStream.Write(dataBytes, 0, dataBytes.Length);
                    cryptoStream.FlushFinalBlock();
                    result = bytesToHexString(iv) + bytesToHexString(memoryStream.ToArray());
                }
            }

            return result;
        }

        /// <summary>
        /// Creates a hash string.
        /// </summary>
        /// <param name="encryptData">Encrypted string</param>
        /// <returns>Hash string</returns>
        public static String createHash(String encryptData)
        {
            byte[] dataBytes = Encoding.UTF8.GetBytes(encryptData);
            return bytesToHexString(SHA1.Create().ComputeHash(dataBytes));
        }

        /// <summary>
        /// Decrypts a string.
        /// </summary>
        /// <param name="keyFile">Key file to encrypt with</param>
        /// <param name="data">Text to be decrypted</param>
        /// <param name="hash">Hash to decrypt with</param>
        /// <returns>A decrypted string</returns>
        public static String decrypt(String keyFile, String data, String hash)
        {
            String result = null;

            if (!hash.Equals(createHash(data)))
            {
                return result;
            }

            AesCryptoServiceProvider aes = new AesCryptoServiceProvider();
            aes.BlockSize = CRYPTO_BLOCK_SIZE;
            aes.KeySize = CRYPTO_KEY_SIZE;
            aes.Mode = CRYPTO_CIPHER_MODE;
            aes.Padding = CRYPTO_PADDING_MODE;

            byte[] key = Encoding.UTF8.GetBytes(getKey(keyFile));
            byte[] iv = hexStringToBytes(data.Substring(0, aes.IV.Length * 2));

            byte[] dataBytes = hexStringToBytes(data.Substring(iv.Length * 2));

            using (MemoryStream MemStream = new MemoryStream(dataBytes))
            {
                using (CryptoStream CryptoStream =
                    new CryptoStream(MemStream, aes.CreateDecryptor(key, iv), CryptoStreamMode.Read))
                {
                    byte[] buffer = new byte[dataBytes.Length];
                    int length = CryptoStream.Read(buffer, 0, buffer.Length);
                    result = Encoding.UTF8.GetString(buffer);
                }
            }


            return result;
        }

        private static String getKey(String fileName)
        {
            String result = null;
            using (FileStream fs = new FileStream(fileName, FileMode.Open, FileAccess.Read))
            {
                byte[] buffer = new byte[fs.Length];
                fs.Read(buffer, 0, buffer.Length);
                result = Encoding.UTF8.GetString(buffer);
            }
            return result.Substring(result.Length - CRYPTO_KEY_SIZE / 8);
        }

        private static String bytesToHexString(byte[] bytes)
        {
            StringBuilder sb = new StringBuilder();
            foreach (byte b in bytes)
            {
                sb.Append(b.ToString("x2"));
            }
            return sb.ToString();
        }

        private static byte[] hexStringToBytes(String hexString)
        {
            byte[] bytes = new byte[hexString.Length / 2];
            for (int i = 0; i < bytes.Length; i++)
            {
                bytes[i] = Convert.ToByte(hexString.Substring(i * 2, 2), 16);
            }
            return bytes;
        }

    }

}
