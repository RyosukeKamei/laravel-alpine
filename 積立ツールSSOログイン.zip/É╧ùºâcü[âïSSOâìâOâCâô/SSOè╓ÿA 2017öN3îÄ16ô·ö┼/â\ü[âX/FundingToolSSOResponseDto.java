/*
 * 統合ＤＢシステム
 * 積立ツールSSOレスポンスパラメータ
 *
 * --修正履歴----
 * 修正日付   NO    修正者   修正履歴
 * 2017/03/06 0001  賀川     新規作成
 *
 */
package jp.co.stonesystem.unvrs.dto;

import java.util.List;

import net.arnx.jsonic.JSONHint;

/** 積立ツールSSOレスポンス DTO */
public class FundingToolSSOResponseDto {
    /** ポータルＩＤ */
    public String portalId;

    /** 取引口座情報 */
    @JSONHint(name = "trade")
    public List<FundingToolTradeInfoDto> tradeList;

    /** システム日時 */
    public String systemDate;

    /** 遷移先URLキー */
    public String redirectUrlKey;
}
