/*
 * 統合ＤＢシステム
 * 積立ツールSSO用取引口座情報
 *
 * --修正履歴----
 * 修正日付   NO    修正者   修正履歴
 * 2017/03/06 0001  賀川     新規作成
 *
 */
package jp.co.stonesystem.unvrs.dto;

import net.arnx.jsonic.JSONHint;

/** 積立ツール用取引口座情報 */
public class FundingToolTradeInfoDto {
    /** サービスコード */
    @JSONHint(ordinal=1)
    public String serviceCd;

    /** 取引ログインID */
    @JSONHint(name = "loginId", ordinal=2)
    public String tradeLoginId;

    /** ステータス */
    @JSONHint(ordinal=3)
    public String status;
}
