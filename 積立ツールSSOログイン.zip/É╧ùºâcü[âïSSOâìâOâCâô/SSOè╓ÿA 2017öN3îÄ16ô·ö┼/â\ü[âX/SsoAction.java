/*
 * 統合ＤＢシステム
 * 共通機能 SSO OUT
 *
 * --修正履歴----
 * 修正日付   NO    修正者   修正履歴
 * 2013/06/10 0001  下羽     Ph.10 基盤移行＋スキーマ統合対応
 * 2015/09/24 0002  下羽     Ph.15 SSOログイン（TrendInvestor）
 * 2016/01/22 0003  下羽     Ph.15 SSO OUT 選択サービスを変更しない
 * 2016/02/17 0004  杉本     Ph.17 TriAutoETF対応
 * 2017/03/06 0005  賀川     Ph.19.0 積立ツール対応
 */
package jp.co.stonesystem.unvrs.action.portal;

import java.util.Date;
import java.util.HashMap;
import java.util.LinkedHashMap;
import java.util.List;
import java.util.Map;

import javax.annotation.Resource;
import javax.servlet.http.HttpSession;

import jp.co.stonesystem.unvrs.action.BaseAction;
import jp.co.stonesystem.unvrs.common.ApplicationException;
import jp.co.stonesystem.unvrs.common.Constants;
import jp.co.stonesystem.unvrs.dto.FundingToolSSORequestDto;
import jp.co.stonesystem.unvrs.dto.FundingToolTradeInfoDto;
import jp.co.stonesystem.unvrs.entity.TmDisclaimer;
import jp.co.stonesystem.unvrs.entity.TmService;
import jp.co.stonesystem.unvrs.entity.TmSystemSetInfo;
import jp.co.stonesystem.unvrs.entity.TtClientBase;
import jp.co.stonesystem.unvrs.entity.TtClientTrade;
import jp.co.stonesystem.unvrs.form.portal.sso.C0003Form;
import jp.co.stonesystem.unvrs.service.TmDisclaimerService;
import jp.co.stonesystem.unvrs.service.TrendPortfolioService;
import jp.co.stonesystem.unvrs.service.TtClientBaseService;
import jp.co.stonesystem.unvrs.service.TtClientTradeService;
import jp.co.stonesystem.unvrs.util.CipherAlgorithm;
import jp.co.stonesystem.unvrs.util.CipherUtil;
import jp.co.stonesystem.unvrs.util.DateUtil;
import jp.co.stonesystem.unvrs.util.MessageDigestAlgorithm;
import jp.co.stonesystem.unvrs.util.SysUtil;
import jp.co.stonesystem.unvrs.util.UaUtil;

import net.arnx.jsonic.JSON;

import org.apache.commons.lang3.exception.ExceptionUtils;
import org.apache.commons.logging.Log;
import org.apache.commons.logging.LogFactory;
import org.seasar.framework.util.StringUtil;
import org.seasar.struts.annotation.ActionForm;
import org.seasar.struts.annotation.Execute;

/**
 * SSO OUT
 *
 * @version 1.0
 */
public class SsoAction extends BaseAction {

    /** ログ */
    private static Log log = LogFactory.getLog(SsoAction.class);


    /** 取引口座サービス */
    @Resource
    protected TtClientTradeService ttClientTradeService;
    /** ディスクレーマーマスタ */
    @Resource
    protected TmDisclaimerService tmDisclaimerService;

    /** TrendPortfolio サービス */
    @Resource
    protected TrendPortfolioService trendPortfolioService;

    /** 顧客基本情報サービス */
    @Resource
    private TtClientBaseService ttClientBaseService;

    /** SSO フォーム画面 */
    @Resource
    @ActionForm
    protected C0003Form c0003Form;


    /**
     * 初期表示処理
     * @return String
     */
    @Execute(validator = false)
    public String index() {

        return null;
    }


    /**
     * Wien SSO(OUT)処理
     * @return String
     * @throws Exception 例外
     */
    @Execute(validator = false, urlPattern = "wien/{serviceCd}")
    public String wien() throws Exception {

        String serviceCd = request.getParameter("serviceCd");

        return ssoOut(serviceCd);
    }


    /**
     * シストレ24 フロント SSO(OUT)処理
     * @return String
     * @throws Exception 例外
     */
    @Execute(validator = false)
    public String vfxMt() throws Exception {

        return ssoVfx(Constants.SERVICE_CD_MRRTRD, "URL_SSO_TOP");
    }

    /**
     * シストレ24 フロント SSO(OUT)処理
     * @return String
     * @throws Exception 例外
     */
    @Execute(validator = false, urlPattern = "vfxMt/{redirectUrlKey}/{depositServiceCd}")
    public String vfxmt3() throws Exception {

        String redirectUrlKey = request.getParameter("redirectUrlKey");
        String depositServiceCd = request.getParameter("depositServiceCd");

        return ssoVfx(Constants.SERVICE_CD_MRRTRD, redirectUrlKey, depositServiceCd);
    }

    /**
     * シストレ24 フロント SSO(OUT)処理
     * @return String
     * @throws Exception 例外
     */
    @Execute(validator = false, urlPattern = "vfxMt/{redirectUrlKey}")
    public String vfxmt2() throws Exception {

        String redirectUrlKey = request.getParameter("redirectUrlKey");

        return ssoVfx(Constants.SERVICE_CD_MRRTRD, redirectUrlKey);
    }

    /**
     * VIKING フロント SSO(OUT)処理
     * @return String
     * @throws Exception 例外
     */
    @Execute(validator = false)
    public String vfxVkg() throws Exception {

        return ssoVfx(Constants.SERVICE_CD_VIKING, "URL_SSO_TOP");
    }

    /**
     * VIKING フロント SSO(OUT)処理
     * @return String
     * @throws Exception 例外
     */
    @Execute(validator = false, urlPattern = "vfxVkg/{redirectUrlKey}/{depositServiceCd}")
    public String vfxvkg3() throws Exception {

        String redirectUrlKey = request.getParameter("redirectUrlKey");
        String depositServiceCd = request.getParameter("depositServiceCd");

        return ssoVfx(Constants.SERVICE_CD_VIKING, redirectUrlKey, depositServiceCd);
    }

    /**
     * VIKING フロント SSO(OUT)処理
     * @return String
     * @throws Exception 例外
     */
    @Execute(validator = false, urlPattern = "vfxVkg/{redirectUrlKey}")
    public String vfxvkg2() throws Exception {

        String redirectUrlKey = request.getParameter("redirectUrlKey");

        return ssoVfx(Constants.SERVICE_CD_VIKING, redirectUrlKey);
    }


    /**
     * TriAutoFX SSO(OUT)処理
     * @return String
     * @throws Exception 例外
     */
    @Execute(validator = false, urlPattern = "tri/{serviceCd}")
    public String tri() throws Exception {

        String serviceCd = request.getParameter("serviceCd");

        return ssoOut(serviceCd);
    }


    /**
     * -- MirrorTrader SSO(OUT)処理
     * Myシストレ24 SSO(OUT)
     * @return String
     * @throws Exception 例外
     */
    @Execute(validator = false)
    public String mt() throws Exception {

        String serviceCd = Constants.SERVICE_CD_MRRTRD;
        DateUtil dateUtil = DateUtil.getInstance();

        // ディスクレーマチェック
        try {
            // 開設済みチェック
            boolean isOpenGrp = false;
            List<String> grpServices = tmServiceService.expandServiceGroup(serviceCd);
            for (String checkServiceCd : grpServices) {
                String serviceStatus = userDto.serviceStatusMap.get(checkServiceCd);
                if (serviceStatus != null && serviceStatus.equals(Constants.CODE_FRONT_ACCOUNT_STATUS_OPEN)) {
                    isOpenGrp = true;
                    break;
                }
            }
            if (isOpenGrp) {
                // 顧客がまだ閲覧していないディスクレーマーを検索する。
                List <TmDisclaimer> disclaimerList = tmDisclaimerService.findUnread(userDto.clientCd, serviceCd);
                if (!disclaimerList.isEmpty()) {
                    log.info("交付書面が未確認。");
                    // 新規ウィンドウにマイページ画面を重複表示させないための遷移変更
                    // "/portal/confirm/disclaimer?forwardUrl=/portal/home/mpref/08/01/"
                    // メニュー、選択サービスの設定
                    selectMenu(serviceCd);
                    // SSO遷移のスクリプトを利用して、親画面をサービストップ経由で交付書面確認通知へ遷移
                    HttpSession session = request.getSession(false);
                    if (session != null) {
                        // 一時的にセッション値を使用して、交付書面確認識別として、確認後の取引システム遷移のためのURLを渡す。
                        session.setAttribute(
                            Constants.SESSION_KEY_TEMP_DISCLAIMER_FORWARD, "/portal/home/mpref/08/01/");
                    }
                    //c0003Form.execScript = "onLoad=\"window.opener.location='/portal/service/';window.close();\"";
                    c0003Form.execScript = "onLoad=\"window.opener.location='/portal/service/';window.open('about:blank', '_self').close();\"";
                    return "C0003.jsp";
                }
            }
        } catch (Exception e) {
            log.error(e.getMessage() + ExceptionUtils.getStackTrace(e));
        }


        // 暗号化キー取得
        TmSystemSetInfo tmSystemSetInfo = tmSystemSetInfoService.findCurrent(
        Constants.PATH_CIPHER_UTIL_KEY_FILE_MRR, dateUtil.getDBSystemDate());
        String keyFile = tmSystemSetInfo.textValue1;

        String portalId = userDto.portalId;
        String tradeLoginId = "";
        //TtClientTrade ttClientTrade = ttClientTradeService.findClientTrade(userDto.clientCd, serviceCd);
        TtClientTrade ttClientTrade = ttClientTradeService.findClientTradeOpen(userDto.clientCd, serviceCd);
        if (ttClientTrade != null) {
            tradeLoginId = ttClientTrade.tradeLoginId;
        }

        // 認証情報の暗号化
        // 日時 文字列書式 GMT toString()形式
        StringBuffer sb = new StringBuffer();
        Date requestDate = dateUtil.getSystemDate();
        String systemDate = dateUtil.toStringISO8601UTC(requestDate);

        sb.append(tradeLoginId).append(",");
        sb.append(portalId).append(",");
        sb.append("URL_SSO_TOP").append(",");
        sb.append(String.valueOf(Integer.parseInt(serviceCd))).append(",");
        sb.append(systemDate);

        String encryptedString = CipherUtil.encrypt(keyFile, sb.toString(), CipherAlgorithm.AES_CBC_ISO10126Padding);
        String hash = CipherUtil.createHash(encryptedString, MessageDigestAlgorithm.SHA1);
        tmSystemSetInfo = tmSystemSetInfoService.findCurrent(Constants.URL_MYST24_NEW, dateUtil.getDBSystemDate());
        c0003Form.data = encryptedString;
        c0003Form.hash = hash;
        c0003Form.execScript = "onLoad='document.myst24Form.submit()'";
        c0003Form.execAction = "action='" + tmSystemSetInfo.textValue1 + "'";
        c0003Form.execFormName = "myst24Form";

        return "C0003.jsp";
    }

    /**
     * 積立ツール SSO(OUT)
     * @return 積立ツールSSOログインURL
     * @throws Exception 例外
     */
    @Execute(validator = false)
    public String ft() throws Exception {
        DateUtil dateUtil = DateUtil.getInstance();
        java.sql.Date date =  dateUtil.getDBSystemDate();

        // SSOパラメータの取得
        // 顧客情報の取得
        TtClientBase ttClientBase = ttClientBaseService.findByClientCd(userDto.clientCd);
        if (ttClientBase == null) {
            throw new ApplicationException("顧客情報の取得に失敗");
        }

        // 各取引口座情報を取得
        List<FundingToolTradeInfoDto> fundingToolTradeInfoDtoList =
                ttClientTradeService.findFundingToolTradeInfo(userDto.clientCd);
        for (FundingToolTradeInfoDto fundingToolTradeInfoDto1: fundingToolTradeInfoDtoList) {
            for (FundingToolTradeInfoDto fundingToolTradeInfoDto2: fundingToolTradeInfoDtoList) {
                if (fundingToolTradeInfoDto1 == fundingToolTradeInfoDto2) {
                    break;
                }
                if (fundingToolTradeInfoDto1.serviceCd.equals(fundingToolTradeInfoDto2.serviceCd)) {
                    throw new ApplicationException(
                            fundingToolTradeInfoDto1.serviceCd + "のサービスコードが2つ存在している");
                }
            }
        }

        // JACCSステータスの取得
        // TODO: 未実装なので直接入力している
        String jaccsStatus = "1";

        // 不備情報の取得
        Map<String, String> defectInfo = new LinkedHashMap<String, String>();
        String errorCode;
        String errorCode1 = Constants.FLG_OFF;
        String errorCode2 = Constants.FLG_OFF;
        String errorCode3 = Constants.FLG_OFF;
        String errorCode4 = Constants.FLG_OFF;

        // 氏名のチェック
        if(jp.co.stonesystem.unvrs.util.StringUtil.isBlank(ttClientBase.clientNameFam) ||
                jp.co.stonesystem.unvrs.util.StringUtil.isBlank(ttClientBase.clientNameNam)) {
            errorCode1 = Constants.FLG_ON;
        }

        // 氏名（カナ）のチェック
        if(jp.co.stonesystem.unvrs.util.StringUtil.isBlank(ttClientBase.clientNameFamKn) ||
                jp.co.stonesystem.unvrs.util.StringUtil.isBlank(ttClientBase.clientNameNamKn)) {
            errorCode2 = Constants.FLG_ON;
        }

        // 性別のチェック
        if(jp.co.stonesystem.unvrs.util.StringUtil.isBlank(ttClientBase.sex)) {
            errorCode3 = Constants.FLG_ON;
        }

        // 生年月日のチェック
        if(ttClientBase.birthday == null) {
            errorCode4 = Constants.FLG_ON;
        }

        // エラーコードの作成
        errorCode = errorCode1 + errorCode2 + errorCode3 + errorCode4;
        defectInfo.put("code", errorCode1 + errorCode2 + errorCode3 + errorCode4);

        // なんらかのエラーが有った場合
        if(!errorCode.equals("0000")) {
            defectInfo.put("message", "顧客情報に不備がありました");
        }

        // 暗号化／複合化ライブラリ用キーファイルパスの取得
        TmSystemSetInfo tmSystemSetInfo = tmSystemSetInfoService.getTmSystemSetInfo(
                Constants.PATH_CIPHER_UTIL_KEY_FILE_FUNDING_TOOL, true, false, false);
        String keyFile = tmSystemSetInfo.textValue1;

        // 認証情報の作成
        FundingToolSSORequestDto fundingToolSSORequestDto = new FundingToolSSORequestDto();
        fundingToolSSORequestDto.portalId = userDto.portalId;
        fundingToolSSORequestDto.clientKbn = userDto.clientKbn;
        fundingToolSSORequestDto.tradeList = fundingToolTradeInfoDtoList;
        fundingToolSSORequestDto.jaccsStatus = jaccsStatus;
        fundingToolSSORequestDto.defectInfo = defectInfo;
        fundingToolSSORequestDto.systemDate = dateUtil.getSystemTimestampString();
        String info = JSON.encode(fundingToolSSORequestDto);

        // 認証情報の暗号化
        String encryptedString = CipherUtil.encrypt(keyFile, info, CipherAlgorithm.AES_CBC_PKC5Padding_KEY128_BLOCK128);

        // ハッシュ値の生成
        String hash = CipherUtil.createHash(encryptedString, MessageDigestAlgorithm.SHA256);

        // 遷移先URLの取得
        tmSystemSetInfo = tmSystemSetInfoService.findCurrent(Constants.URL_FUNDING_TOOL_SSO_LOGIN, dateUtil.getDBSystemDate());

        // SSOログイン
//        String formName = "funding_tool";
//        c0003Form.data = encryptedString;
//        c0003Form.hash = hash;
//        c0003Form.execScript = "onLoad='document." + formName + ".submit()'";
//        c0003Form.execAction = "action='" + tmSystemSetInfo.textValue1 + "'";
//        c0003Form.execFormName = formName;

//        return "C0003.jsp";
        System.out.println(info);
        System.out.println(encryptedString);
        System.out.println(hash);
      return "C0003.jsp";
    }

    /**
     *  Trend Portfolio SSO(OUT)処理
     *
     * @return C0096
     * @throws Exception 例外
     */
    @Execute(validator = false, urlPattern = "tp")
    public String trendPortfolio() throws Exception {

        String result = null;
        String serviceCd = Constants.SERVICE_CD_DMACFD;

        // ディスクレーマチェック
        try {
            // 開設済みチェック
            boolean isOpenGrp = false;
            List<String> grpServices = tmServiceService.expandServiceGroup(serviceCd);
            for (String checkServiceCd : grpServices) {
                String serviceStatus = userDto.serviceStatusMap.get(checkServiceCd);
                if (serviceStatus != null && serviceStatus.equals(Constants.CODE_FRONT_ACCOUNT_STATUS_OPEN)) {
                    isOpenGrp = true;
                    break;
                }
            }
            if (isOpenGrp) {
                // 顧客がまだ閲覧していないディスクレーマーを検索する。
                List <TmDisclaimer> disclaimerList = tmDisclaimerService.findUnread(userDto.clientCd, serviceCd);
                if (!disclaimerList.isEmpty()) {
                    log.info("交付書面が未確認。");
                    // メニュー、選択サービスの設定
                    selectMenu(serviceCd);
                    // SSO遷移のスクリプトを利用して、親画面をサービストップ経由で交付書面確認通知へ遷移
                    HttpSession session = request.getSession(false);
                    if (session != null) {
                        // 一時的にセッション値を使用して、交付書面確認識別として、確認後の取引システム遷移のためのURLを渡す。
                        session.setAttribute(
                            Constants.SESSION_KEY_TEMP_DISCLAIMER_FORWARD, "/portal/home/submit/16/01/");
                    }
                    c0003Form.execScript = "onLoad=\"window.opener.location='/portal/service/';window.close();\"";
                    return "C0003.jsp";
                }
            }
        } catch (Exception e) {
            log.error(e.getMessage() + ExceptionUtils.getStackTrace(e));
        }

        // 遷移先情報取得
        TmService tmService = tmServiceService.findByServiceCd(serviceCd);
        String reqUrl = null;
        String reqFormName = null;
        String tradeSystemUrl = null;
        String androidTrdSysUrl = null;
        String androidTrdSysSsoUrl = null;
        String iosTrdSysUrl = null;
        String iosTrdSysSsoUrl = null;

        // 遷移先情報取得可否チェック
        if (tmService == null) {
            throw new ApplicationException("サービスマスタ取得失敗", Constants.EXP_RES_KEY_REJECT);
        }
        reqUrl = tmService.tradingSystemSsoUrl;
        reqFormName = tmService.ssoForm;
        tradeSystemUrl = tmService.tradingSystemUrl;

        boolean isAndroidAgent = UaUtil.isAndroidAgent(request.getHeader(Constants.USER_AGENT));
        boolean isIosAgent = UaUtil.isIosAgent(request.getHeader(Constants.USER_AGENT));

        if (isAndroidAgent) {
            // ログイン端末がAndroidかつ、専用の遷移先が用意されていた場合
            if (!StringUtil.isBlank(androidTrdSysSsoUrl)) {
                reqUrl = androidTrdSysSsoUrl;
            } else if (!StringUtil.isBlank(androidTrdSysUrl)) {
                reqUrl = null;
                tradeSystemUrl = androidTrdSysUrl;
            }
        } else if (isIosAgent) {
            // ログイン端末がiOSの場合かつ、専用の遷移先が用意されていた場合
            if (!StringUtil.isBlank(iosTrdSysSsoUrl)) {
                reqUrl = iosTrdSysSsoUrl;
            } else if (!StringUtil.isBlank(iosTrdSysUrl)) {
                reqUrl = null;
                tradeSystemUrl = iosTrdSysUrl;
            }
        }

        if (reqUrl == null || reqUrl.trim().length() < 1
                || reqFormName == null || reqFormName.trim().length() < 1) {

                if (tradeSystemUrl != null) {
                    if (tradeSystemUrl.indexOf("?") > 0) {
                        result = tradeSystemUrl + "&redirect=true";
                    } else {
                        result = tradeSystemUrl + "?redirect=true";
                    }
                }
        } else {
	        // 取引情報取得
	        TtClientTrade ttClientTrade = ttClientTradeService.findClientTrade(userDto.clientCd, serviceCd);
	        String tradeLoginId = null;
	        String tradePassword = null;

	        // 取引情報取得可否チェック
	        if (ttClientTrade == null) {
	            throw new ApplicationException("取引情報取得失敗", Constants.EXP_RES_KEY_REJECT);
	        }
	        tradeLoginId = ttClientTrade.tradeLoginIdSub1;
	        tradePassword = ttClientTrade.tradePasswordSub1;
	        if (tradeLoginId == null || tradePassword == null) {
	            log.warn("clientCd " + userDto.clientCd + ", serviceCd " + serviceCd +
	                    " (tradeLoginId " + tradeLoginId + ", tradePassword " + tradePassword + ")");
	            throw new ApplicationException("データ不正", Constants.EXP_RES_KEY_REJECT);
	        }
	        tradePassword = SysUtil.getInstance().actDecodeString(tradePassword);

	        // SSOパラメータ暗号化
	        Map<String, String> encrypted = trendPortfolioService.ssoEncrypt(tradeLoginId, tradePassword);
	        c0003Form.data = encrypted.get("encryptedString");
	        c0003Form.hash = encrypted.get("messageDigest");

	        // 遷移先 リダイレクト POST 設定
	        c0003Form.execScript = "onLoad='document." + reqFormName + ".submit()'";
	        c0003Form.execAction = "action='" + reqUrl + "'";
	        c0003Form.execFormName = reqFormName;

	        return "C0096.jsp";
        }

        return result;
    }


    /**
     * SSO OUT
     * @param serviceCd サービスコード
     * @return String
     * @throws Exception 例外
     */
    protected String ssoOut(String serviceCd) throws Exception {

        String result = null;

        String reqUrl = null;
        String reqFormName = null;
        String tradeSystemUrl = null;
        String androidTrdSysUrl = null;
        String androidTrdSysSsoUrl = null;
        String iosTrdSysUrl = null;
        String iosTrdSysSsoUrl = null;

        TmSystemSetInfo tmSystemSetInfo = null;
        DateUtil dateUtil = DateUtil.getInstance();

        TmService tmService = tmServiceService.findByServiceCd(serviceCd);
        if (tmService != null) {
            reqUrl = tmService.tradingSystemSsoUrl;
            reqFormName = tmService.ssoForm;
            tradeSystemUrl = tmService.tradingSystemUrl;
            androidTrdSysUrl = tmService.androidTrdSysUrl;
            androidTrdSysSsoUrl = tmService.androidTrdSysSsoUrl;
            iosTrdSysUrl = tmService.iosTrdSysUrl;
            iosTrdSysSsoUrl = tmService.iosTrdSysSsoUrl;
        }

        boolean isAndroidAgent = UaUtil.isAndroidAgent(request.getHeader(Constants.USER_AGENT));
        boolean isIosAgent = UaUtil.isIosAgent(request.getHeader(Constants.USER_AGENT));

        if (isAndroidAgent) {
            // ログイン端末がAndroidかつ、専用の遷移先が用意されていた場合
            if (!StringUtil.isBlank(androidTrdSysSsoUrl)) {
                reqUrl = androidTrdSysSsoUrl;
            } else if (!StringUtil.isBlank(androidTrdSysUrl)) {
                reqUrl = null;
                tradeSystemUrl = androidTrdSysUrl;
            }
        } else if (isIosAgent) {
            // ログイン端末がiOSの場合かつ、専用の遷移先が用意されていた場合
            if (!StringUtil.isBlank(iosTrdSysSsoUrl)) {
                reqUrl = iosTrdSysSsoUrl;
            } else if (!StringUtil.isBlank(iosTrdSysUrl)) {
                reqUrl = null;
                tradeSystemUrl = iosTrdSysUrl;
            }
        }

        if (reqUrl == null || reqUrl.trim().length() < 1
            || reqFormName == null || reqFormName.trim().length() < 1) {

            if (tradeSystemUrl != null) {
                if (tradeSystemUrl.indexOf("?") > 0) {
                    result = tradeSystemUrl + "&redirect=true";
                } else {
                    result = tradeSystemUrl + "?redirect=true";
                }
            }

        } else {

            // 取引システムID の取得
            TtClientTrade ttClientTrade = null;
            String tradeLoginId = null;
            String portalId = userDto.portalId;
            ttClientTrade = ttClientTradeService.findClientTrade(userDto.clientCd, serviceCd);
            if (ttClientTrade != null) {
                tradeLoginId = ttClientTrade.tradeLoginId;
            }
            if (tradeLoginId == null) {
                throw new ApplicationException("データ不正", Constants.EXP_RES_KEY_REJECT);
            }

            String keyFile = null;
            if (serviceCd.equals(Constants.SERVICE_CD_MRRTRD)) {
                // 暗号化キー取得
                tmSystemSetInfo = tmSystemSetInfoService.findCurrent(
                    Constants.PATH_CIPHER_UTIL_KEY_FILE_MRR, dateUtil.getDBSystemDate());
                keyFile = tmSystemSetInfo.textValue1;

                // 認証情報の暗号化
                // 日時 文字列書式 GMT toString()形式
                StringBuffer sb = new StringBuffer();
                Date requestDate = dateUtil.getSystemDate();
                String systemDate = dateUtil.toStringISO8601UTC(requestDate);

                sb.append(tradeLoginId).append(",");
                sb.append(portalId).append(",");
                sb.append("78").append(",");
                sb.append("ja-JP").append(",");
                sb.append("0").append(",");
                sb.append(systemDate);

                String encryptedString =
                        CipherUtil.encrypt(keyFile, sb.toString(), CipherAlgorithm.AES_CBC_ISO10126Padding);
                String hash = CipherUtil.createHash(encryptedString, MessageDigestAlgorithm.SHA1);

                c0003Form.data = encryptedString;
                c0003Form.hash = hash;

                // 遷移先 リダイレクト POST 設定
                c0003Form.execScript = "onLoad='document." + reqFormName + ".submit()'";
                c0003Form.execAction = "action='" + reqUrl + "'";
                c0003Form.execFormName = reqFormName;

                return "C0008.jsp";

            } else {
                // 暗号化キー取得
                String cipherKey = null;
                if (serviceCd.equals(Constants.SERVICE_CD_TRIAUTO) ||
                    serviceCd.equals(Constants.SERVICE_CD_TRIAUTO_ETF)) {
                    cipherKey = Constants.PATH_CIPHER_UTIL_KEY_FILE_TRIAUTO;
                } else {
                    cipherKey = Constants.PATH_CIPHER_UTIL_KEY_FILE;
                }
                tmSystemSetInfo = tmSystemSetInfoService.findCurrent(
                        cipherKey, dateUtil.getDBSystemDate());
                keyFile = tmSystemSetInfo.textValue1;

                // 認証情報の暗号化
                Date systemDate = dateUtil.getSystemDate();
                //// 遷移先区分
                //String redirectType = serviceCd;

                HashMap<String, Object> params = new HashMap<String, Object>();
                params.put(Constants.SSO_PARAM_TRADE_LOGIN_ID, tradeLoginId);
                params.put(Constants.SSO_PARAM_PORTAL_ID, portalId);
                params.put(Constants.SSO_PARAM_SYSTEM_DATE, systemDate);
                //params.put(Constants.SSO_PARAM_REDIRECT_TYPE, redirectType);

                String encodeString = CipherUtil.encrypt(keyFile, params);

                // ハッシュ値の生成
                String hash = CipherUtil.createHash(encodeString);

                c0003Form.data = encodeString;
                c0003Form.hash = hash;

                // 遷移先 リダイレクト POST 設定
                c0003Form.execScript = "onLoad='document." + reqFormName + ".submit()'";
                c0003Form.execAction = "action='" + reqUrl + "'";
                c0003Form.execFormName = reqFormName;
            }

            result = "C0003.jsp";
        }

        return result;
    }


    /**
     * VFX SSO (OUT)
     *
     * @param serviceCd サービスコード
     * @param redirectUrlKey 遷移先URLキー
     * @return String
     * @throws Exception 例外
     */
    protected String ssoVfx(String serviceCd, String redirectUrlKey) throws Exception {

        return ssoVfx(serviceCd, redirectUrlKey, null);
    }

    /**
     * VFX SSO (OUT)
     *
     * @param serviceCd サービスコード
     * @param redirectUrlKey 遷移先URLキー
     * @param depositServiceCd 入金先サービスコード
     * @return String
     * @throws Exception 例外
     */
    protected String ssoVfx(String serviceCd, String redirectUrlKey, String depositServiceCd) throws Exception {

        String result = null;

        TmSystemSetInfo tmSystemSetInfo = null;
        DateUtil dateUtil = DateUtil.getInstance();

        if (serviceCd != null && serviceCd.equals(Constants.SERVICE_CD_MRRTRD)) {
            tmSystemSetInfo = tmSystemSetInfoService.findCurrent(
                    Constants.URL_FRONT_SYS_8, dateUtil.getDBSystemDate());
        } else if (serviceCd != null && serviceCd.equals(Constants.SERVICE_CD_VIKING)) {
            tmSystemSetInfo = tmSystemSetInfoService.findCurrent(
                    Constants.URL_FRONT_SYS_9, dateUtil.getDBSystemDate());
        }
        if (tmSystemSetInfo == null) {
            throw new ApplicationException("データ不正", Constants.EXP_RES_KEY_REJECT, false, true);
        }

        String reqUrl = tmSystemSetInfo.textValue2;
        String reqFormName = tmSystemSetInfo.textValue3;

        if (reqUrl == null || reqFormName == null) {
            throw new ApplicationException("データ不正", Constants.EXP_RES_KEY_REJECT, false, true);
        }

        // 取引システムID の取得
        String tradeLoginId = null;
        String portalId = userDto.portalId;
        TtClientTrade ttClientTrade = ttClientTradeService.findClientTrade(userDto.clientCd, serviceCd);
        if (ttClientTrade != null) {
            tradeLoginId = ttClientTrade.tradeLoginId;
        }
        if (tradeLoginId == null) {
            log.warn("tradeLoginId not found, clientCd " + userDto.clientCd + ", serviceCd " + serviceCd);
            throw new ApplicationException("データ不正", Constants.EXP_RES_KEY_REJECT, false, true);
        }

        // 暗号化キーファイル
        String keyFile = null;
        tmSystemSetInfo = tmSystemSetInfoService.findCurrent(
                Constants.PATH_CIPHER_UTIL_KEY_FILE_VFX, dateUtil.getDBSystemDate());
        keyFile = tmSystemSetInfo.textValue1;

        // 認証情報の暗号化
        Date systemDate = dateUtil.getSystemDate();

        HashMap<String, Object> params = new HashMap<String, Object>();
        params.put(Constants.SSO_PARAM_TRADE_LOGIN_ID, tradeLoginId);
        params.put(Constants.SSO_PARAM_PORTAL_ID, portalId);
        params.put(Constants.SSO_PARAM_SYSTEM_DATE, systemDate);
        params.put(Constants.SSO_PARAM_REDIRECT_URL_KEY,  redirectUrlKey);
        if (depositServiceCd != null) {
            params.put(Constants.SSO_PARAM_DEPOSIT_SERVICE_KBN,  depositServiceCd);
        }

        String encodeString = CipherUtil.encrypt(keyFile, params);

        // ハッシュ値の生成
        String hash = CipherUtil.createHash(encodeString);

        c0003Form.data = encodeString;
        c0003Form.hash = hash;

        // 遷移先 リダイレクト POST 設定
        c0003Form.execScript = "onLoad='document." + reqFormName + ".submit()'";
        c0003Form.execAction = "action='" + reqUrl + "'";
        c0003Form.execFormName = reqFormName;

        result = "C0005.jsp";

        return result;
    }


    /* (非 Javadoc)
     * @see jp.invast.itd.action.BaseAction#copyUserDtoFromBaseForm()
     */
    @Override
    public void copyUserDtoFromBaseForm() {
        // ignore selectedMenu等が更新されないように、SSO OUT時は セッションの userDtoを更新しない
    }

    /* (非 Javadoc)
     * @see jp.invast.itd.action.BaseAction#copyUserDtoToBaseForm()
     */
    @Override
    public void copyUserDtoToBaseForm() {
        // ignore
    }
}
