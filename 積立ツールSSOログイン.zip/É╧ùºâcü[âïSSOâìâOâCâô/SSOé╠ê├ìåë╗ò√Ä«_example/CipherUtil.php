<?php

/**
 * SSOログイン関連
 */
class CipherUtil {
    
    /**
     * SSOログイン：　外部->MyST24
     */
    public static function ssoLogin($message, $key, $messageDigest=null){
        $util = new CipherUtil();
        return $util->decryptSSO($message, $key, $messageDigest);
    }
    
    /**
     * MirrorTraderへSSOログインURLを作成
     */
    public static function getMirrorTraderSSOLoginURL($tradeLoginId, $portalId) {        
        $ssoURL = SystemSet::getUrlValue(SystemSet::URL_TRADE_LOGIN);
        $brokerId = SystemSet::getValue(SystemSet::MT_BROKER_ID);   
        $key = SystemSet::getValue(SystemSet::MT_ACCESS_KEY);   

        //UTC time in the format "yyyy-MM-dd'T'HH:mm:ss.SSS";
        $utcDate = gmdate("Y-m-d\TH:i:s", time()-120).".000"; 
        $lang = (LangUtil::lang()==Constants::LANGUAGE_JA)?"ja-JP":"en-US";
        $ssoParams = Array($tradeLoginId, $portalId, $brokerId, $lang, "0", $utcDate);
        
        $token = CipherUtil::tokenForTradency($ssoParams, $key);
        $messageDigest = hash("sha1", $token);
        $source = SystemSet::getValue(SystemSet::MT_PORTFOLIOMNG_SOURCE);
        
        $ssoURL = $ssoURL."?token=".$token."&messageDigest=".$messageDigest."&source=".$source;
                    
        return $ssoURL;
    }
    
    /**
     * SSOログイン、ストラテジー登録：　MyST24->MyPage,Vfx
     */
    public static function tokenForMypage($tradeId, $portalId, $vfx=FALSE){
        //imr000096,50918733,URL_SSO_TOP,8,2013-02-25T00:44:09.9352817
        $dateNow = time()-120;
        $dateGM = gmdate("Y-m-d",$dateNow)."T".gmdate("H:i:s",$dateNow).'.000';
        $params = Array($tradeId, $portalId, ($vfx===FALSE)?"URL_SSO_PORTAL_TOP":"URL_SSO_PAYMENT", "8", $dateGM);
        $util = new CipherUtil();
        $data = $util->encrypt($util->paramString($params), SystemSet::getValue(SystemSet::MT_ACCESS_KEY));
        $digest = sha1($data);
        return Array("data"=>$data, "messageDigest"=>$digest);
    }
    
    /**
     * SSOログイン、ストラテジー登録：　MyST24->MirroTrader
     */
    public static function tokenForTradency($params, $key){
        $util = new CipherUtil();
        $paramStr = $util->paramString($params);
        //Yii::log("tokenForTradency: ".$paramStr);
        return $util->encrypt($paramStr, $key);
    }
    
    /**
     * SSOログイン：　MyST24->ストラテジーカード）
     */
    public static function tokenForStrategyCard($portalId, $pivateKey){       
        $date = date('YmdHis', strtotime("-5 min"));
        $key = hash("md5", $date);
        $res = hash("sha256",$portalId.$date.$key.$pivateKey);
        return "portalId=".$portalId."&date=".$date."&key=".$key."&res=".$res;
    }
    
     /**
     * WebSocket配信用認証Token
     */
    public static function tokenForStreaming($portalId, $tradeId, $source, $data=''){
        $util = new CipherUtil();
        $params = Array($portalId, $tradeId, date('Y-m-d H:i:s', time()), $source, $data);
        $paramStr = $util->paramString($params);
        //Yii::log("tokenForTradency: ".$paramStr);
        return $util->encrypt($paramStr, SystemSet::getValue("STREAMING_TOKEN_KEY"));
    }
    
    
    public function paramString($params){
        $str = "";
        foreach($params as $param){
            $str = $str.",".$param;
        }
        return substr($str, 1);
    }

    public function encrypt($message, $key){   
        try {
            $cliper = MCRYPT_RIJNDAEL_128;
            $mode = MCRYPT_MODE_CBC;
            $iv_size = mcrypt_get_iv_size($cliper, $mode);
            $iv = mcrypt_create_iv($iv_size, MCRYPT_RAND);
            $ivStr = $this->bin2hex($iv);
            $message = $this->pad_ISO_10126($message, 16);
            $enc = mcrypt_encrypt($cliper, 
                    $key, 
                    $message,
                    $mode, 
                    $iv);
            $encMsg = $this->bin2hex($enc);
            $msg = $ivStr.$encMsg;
            return $msg;
        } catch (Exception $e) {
            Yii::log($e->getMessage().$e->getTraceAsString(), CLogger::LEVEL_WARNING);
            return "";
        }
        
    }
    
    public function decryptSSO($message, $key, $messageDigest=null) {
        try {
            if($messageDigest!=null) {
                if(sha1($message)!=$messageDigest)
                    throw new Exception("messageDigest invalid.");                
            }
            $cliper = MCRYPT_RIJNDAEL_128;
            $mode = MCRYPT_MODE_CBC;
            $iv_size = mcrypt_get_iv_size($cliper, $mode)*2;
            //$key_size = mcrypt_get_key_size($cliper, $mode);
            $iv = substr($message, 0, $iv_size);
            if(strlen($iv)!=$iv_size /*|| strlen($key)!=$key_size*/)
                return "";
            //Yii::log("[decrypt]".$key.",".$this->hex2bin($iv));
            $msg = substr($message, $iv_size);  
            $rawMsg = $this->unpad_ISO_10126(mcrypt_decrypt($cliper, 
                    $key, 
                    $this->hex2bin($msg),
                    $mode, 
                    $this->hex2bin($iv)));
            return $rawMsg;
        } catch (Exception $e) {
            Yii::log($e->getMessage().$e->getTraceAsString(), CLogger::LEVEL_WARNING);
            return "";
        }
    } 
  
 
    private function pad_ISO_10126($data, $block_size)
    {
        //mcrypt_create_iv
        $padding = $block_size - (strlen($data) % $block_size);
        //Yii::log("pad_ISO_10126 len=".$padding);
        for($x=1; $x<$padding; $x++)
            $data = $data.chr($padding);
        return $data . chr($padding);
    }
    
    private function unpad_ISO_10126($data)
    {
        $length = ord(substr($data, -1));
        
        //Yii::log("unpad_ISO_10126 len=".$length);
        return substr($data, 0, strlen($data)-$length);
    }
    
    private function hex2bin($hex_string) {
        return pack('H*', $hex_string);
    }
    private function bin2hex($bin_string) {
        $arr = unpack('H*', $bin_string);
        $str = "";
        foreach($arr as $a){
            $str = $str.$a;
        }
        return $str;
    }
}
