<?php
/*
 * 実験（このファイルだけでの動作確認はしていない）
 */
$string = '{"portalId":"12345678","clientKbn":"1","trade":[{"serviceCd":"01","loginId":null,"status":"1"},{"serviceCd":"17","loginId":"12345678","status":"2"}],"jaccsStatus":"0","defectInfo":{"code":"0000"},"systemDate":"2017-03-15 17:51:48.066"}';
/*
 * JSONからオブジェクトにする
 */
$decorded = json_decode($string);
/*
 * オブジェクト化されていることを確認
 * ※tradeは配列
 */
echo('portalId : '.$decorded->portalId.'<br>');
echo('clientKbn : '.$decorded->clientKbn.'<br>');
echo('trade[0] serviceCd : '.$decorded->trade[0]->serviceCd.'<br>');
echo('trade[0] loginId : '.$decorded->trade[0]->loginId.'<br>');
echo('trade[0] status : '.$decorded->trade[0]->status.'<br>');
echo('trade[1] serviceCd : '.$decorded->trade[1]->serviceCd.'<br>');
echo('trade[1] loginId : '.$decorded->trade[1]->loginId.'<br>');
echo('trade[1] status : '.$decorded->trade[1]->status.'<br>');
echo('jaccsStatus : '.$decorded->jaccsStatus.'<br>');
echo('defectInfo code : '.$decorded->defectInfo->code.'<br>');
echo('systemDate : '.$decorded->systemDate.'<br>');
/*
 * 実験終了
 */
?>